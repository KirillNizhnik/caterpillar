<?php 

/**
 *	Renders "Load More" element and pagination for users without JS and crawlers
 *
 * 	@see mu-plugins/fx-load-more/includes/shortcodes/fx-load-more-pagination.php
 */
echo apply_shortcodes( '[fx_load_more_pagination]' ); 