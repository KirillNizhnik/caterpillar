<!-- footer -->
<?php $home_url   = get_home_url(); ?>
<footer class="page-footer" id="page-footer">
    <div class="container">
        <div class="footer-top clearfix">
            <div class="footer-logo-address">
                <div class="footer-logo">
                    <a href="<?php echo esc_url( $home_url ); ?>">
                        <?php if( get_field('show_ag_header', get_queried_object() ) == 'yes'): ?>
                            <?php echo fx_get_image_tag(15643); ?>
                            <?php else: ?>
                        <?php echo fx_get_image_tag( get_field( 'footer_logo', 'option' ), [''], true, 'full' ); ?>
                        <?php endif; ?>
                    </a>
                </div>
                <?php if(is_page(18341)): ?>
                    <div class="footer-address">
                        <a href="<?php the_field('footer_location', 'option'); ?>"><span class="icon-location-on"></span>VIEW OUR LOCATIONS</a>                        
                        <a href="951-823-8556">
                            <span class="icon-phone-alt"></span><strong>CALL US!</strong> 951.823.8556
                        </a>

                    </div>
                
                <?php else: ?>
                    <div class="footer-address">
                        <a href="<?php the_field('footer_location', 'option'); ?>"><span class="icon-location-on"></span>VIEW OUR LOCATIONS</a>
                        <?php $link  = get_field('footer_phone', 'option'); ?>
                        <?php if($link): ?>
                        <a href="<?php echo $link['url']; ?>">
                            <span class="icon-phone-alt"></span><strong>CALL US!</strong> <?php echo $link['title']; ?>
                        </a>
                        <?php endif; ?>

                    </div>
                <?php endif;?>
                <!-- <div class="language-button hidden-md-up push-bottom">
                    <?php // echo do_shortcode('[weglot_switcher]'); ?>
                </div> -->
                <div class="social-media hidden-xs-down hidden-md-up">
                    <a href="<?php the_field('facebook', 'option'); ?>"><span class="fa fa-facebook"></span></a>
                    <a href="<?php the_field('linkedin', 'option'); ?>"><span class="fa fa-linkedin"></span></a>
                    <a href="<?php the_field('twitter', 'option'); ?>"><span class="fa fa-twitter"></span></a>
                    <a href="<?php the_field('instagram', 'option'); ?>"><span class="fa fa-instagram"></span></a>
                </div>
                <div class="backToTop hidden-sm-up">
                    <a href="javascript:void(0);" class="btn btn-primary back-to-top">Back to top</a>
                </div>
            </div>
            <div class="footer-short-links clearfix hidden-sm-down">
                <div class="footer-short-links-box">
                    <h4>QUICK LINKS</h4>
                    <div class="footer-short-links-items">
                        <?php while( have_rows('quick_links_list', 'option') ): the_row();  ?>
                             <?php $link  = get_sub_field('quick_links_item', 'option'); ?>
                                <?php if($link): ?><a href="<?php echo $link['url']; ?>"><?php echo $link['title']; ?></a><?php endif; ?>
                        <?php endwhile; ?>
                    </div>
                </div>
                <div class="footer-short-links-box">
                    <h4>RESOURCES</h4>
                    <div class="footer-short-links-items">
                        <?php while( have_rows('resources_list', 'option') ): the_row();  ?>
                             <?php $link  = get_sub_field('resources_list_item', 'option'); ?>
                                <?php if($link): ?><a href="<?php echo $link['url']; ?>"><?php echo $link['title']; ?></a><?php endif; ?>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
            <div class="footer-newsletter">
                <h4>SIGN UP FOR OUR NEWSLETTER</h4>
                <p>Signup to receive all the latest updates from Quinn!</p>
                <div class="footer-newsletter-form">

                    <div class="footer-newsletter-field">
                    <?php echo do_shortcode(get_field('footer_contact_form', 'option')); ?>
                    </div>
                </div>
                <div class="social-media hidden-sm-up">
                    <p>FOLLOW US</p>
                    <div class="">
                        <a href="<?php the_field('facebook', 'option'); ?>"><span class="fa fa-facebook"></span></a>
                        <a href="<?php the_field('linkedin', 'option'); ?>"><span class="fa fa-linkedin"></span></a>
                        <a href="<?php the_field('twitter', 'option'); ?>"><span class="fa fa-twitter"></span></a>
                        <a href="<?php the_field('instagram', 'option'); ?>"><span class="fa fa-instagram"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container clearfix">
            <div class="social-media hidden-sm-down">
                <a href="<?php the_field('facebook', 'option'); ?>"><span class="fa fa-facebook"></span></a>
                <a href="<?php the_field('linkedin', 'option'); ?>"><span class="fa fa-linkedin"></span></a>
                <a href="<?php the_field('twitter', 'option'); ?>"><span class="fa fa-twitter"></span></a>
                <a href="<?php the_field('instagram', 'option'); ?>"><span class="fa fa-instagram"></span></a>
            </div>
            <div class="footer-bottom-link">
                <ul>
                    <li><a href="<?php the_field('site_credits', 'option'); ?>">Site Credits</a></li>
                    <li><a href="<?php the_field('sitemap', 'option'); ?>">Sitemap</a></li>
                    <li><a href="https://www.quinncompany.com/legal-notices/">Legal Notices</a></li>
                    <li>Copyright© 2023. All Rights Reserved</li>
                </ul>
            </div>
            <div class="backToTop hidden-xs-down">
                <a href="javascript:void(0);" class="btn btn-primary back-to-top">Back to top</a>
            </div>
        </div>
    </div>
</footer>
<?php //echo do_shortcode('[cookies_revoke]'); ?>
<!-- footer -->

    <!-- Back To Top Icon area
    <button class="back-to-top js-back-to-top" type="button">
        <span class="back-to-top__label">Back to top</span>
        <i class="icon-arrow-up"></i>
    </button>
    -->

        <?php wp_footer(); ?>
          <?php
    /*       add_action(
	'wp_enqueue_scripts',
	function () {
if (!wp_script_is('contact-form-7')) {
                            wp_enqueue_script('contact-form-7');
                        }
}, 	PHP_INT_MAX


);  */
                        ?>
    </body>
</html>
