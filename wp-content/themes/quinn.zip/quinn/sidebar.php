<aside class="page-sidebar">
    <?php dynamic_sidebar( 'sidebar' ); ?>
    
</aside>
