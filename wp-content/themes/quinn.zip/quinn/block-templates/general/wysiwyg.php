<section class="wysiwyg section-margins <?php the_field('background_color'); ?>">
	<div class="container">
		<div class="wysiwyg-content">
			<?php the_field( 'content' ); ?>
		</div>
	</div>
</section>