<?php 

?>


<section class="machine-cards location-card">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="filter-category clearfix">
                    
                        <div class="inner-location-map">
                            <?php echo do_shortcode( '[locations-map]' ); ?>
                        </div>
                           <!-- <div class="location-search-zip">
                                <h5>Search by zip code</h5>
                                <div class="location-search-zip-control">
                                    <input type="text" name="" placeholder="12345">
                                    <button class="btn btn-secondary"><span class="hidden-sm-down">Search</span></button>
                                </div>
                            </div> -->
                        
                       <!-- <form class="wpcm-service__form" method="POST">
                            <div class="filter-search-category">
                                <h5>Filter by location</h5>
                                <div class="filter-search-category-select">
                                    <select>
                                        <option>ANY TYPE</option>
                                        <?php foreach ( $service_terms as $term ) : ?>
                                        <option><?php echo $term->name; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="filter-search-category-button">
                                    <button type="submit" class="btn btn-secondary">Search</button>
                                </div>
                            </div>
                            </form> -->
                </div>
            </div>
        </div>
        <div class="machine-cards-wrapper search-card-machine">
            <?php echo do_shortcode('[locations-list]'); ?> 
        </div>
    </div>
</section>